import Layout from './Layout/Layout'
import NotFound from './NotFound/NotFound'
import Home from './Home/Home'
import Navbar from './Navbar/Navbar'


export default{
    Layout,NotFound,Home ,Navbar
}